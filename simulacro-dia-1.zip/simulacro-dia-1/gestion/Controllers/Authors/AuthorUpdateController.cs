using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Authors
{
    public class AuthorUpdateController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;
        public AuthorUpdateController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpPut("{id}")]
        [Route("api/authors/{id}/update")]
        public IActionResult Update(int id, [FromBody] Author author)
        {
            if(author == null)
            {
                return BadRequest("El Objeto autor es nullo");
            }
            _authorRepository.Update(author);
            return Ok(new { message = "El Autor Se Ha Actualizado Correctamente" });
        }
    }
}