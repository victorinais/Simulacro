using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Authors
{
    public class AuthorDeleteControll : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;
        public AuthorDeleteControll(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/authors/{id}/delete")]
        public IActionResult Delete(int id)
        {
            _authorRepository.Delete(id);
            return Ok(new { message = "El Autor Se Ha Eliminado Correctamente" });
        }
    }
}