using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Authors
{
    public class AuthorsController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;
        public AuthorsController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpGet]
        [Route("api/authors")]
        public IEnumerable<Author> GetAuthors(){
            return _authorRepository.GetAll();
        }
        [HttpGet]
        [Route("api/authors/{id}")]
        public Author Details(int id){
            return _authorRepository.GetById(id);
        }
    }
}