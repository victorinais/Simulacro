using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Authors
{
    public class AuthorCreateController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;
       public AuthorCreateController(IAuthorRepository authorRepository)
       {
            _authorRepository = authorRepository;
       }

       [HttpPost]
       [Route("api/authors/create")]
       public IActionResult Create([FromBody] Author author)
       {
        if(author == null)
        {
            return BadRequest("El Objeto autor es nullo");
        }
        _authorRepository.Add(author);
        return Ok(new { message = "El Autor Se Ha Creado Correctamente" });
       } 
    }
}