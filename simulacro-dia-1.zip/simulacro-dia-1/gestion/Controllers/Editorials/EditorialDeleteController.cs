using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Editorials
{
    public class EditorialDeleteController : ControllerBase
    {
        private readonly IEditorialRepository _editorialRepository;
        public EditorialDeleteController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/editorials/{id}/delete/")]
        public IActionResult Delete(int id)
        {
            _editorialRepository.Delete(id);
            return Ok(new { message = "El Libro Se Ha Cambiado de Estdo a Inactivo Correctamente" });
        }
    }
}