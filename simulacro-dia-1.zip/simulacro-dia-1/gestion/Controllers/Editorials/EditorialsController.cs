using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Editorials
{
    public class EditorialsController : ControllerBase
    {
        private readonly IEditorialRepository _editorialRepository;
        public EditorialsController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpGet]
        [Route("api/editorials")]
        public IEnumerable<Editorial> GetEditorials(){
            return _editorialRepository.GetAll();
        }
        [HttpGet]
        [Route("api/editorials/{id}")]
        public Editorial Details(int id){
            return _editorialRepository.GetById(id);
        }
    }
}