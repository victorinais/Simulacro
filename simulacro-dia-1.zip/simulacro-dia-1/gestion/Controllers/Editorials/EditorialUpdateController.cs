using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Editorials
{
    public class EditorialUpdateController : ControllerBase
    {
        private readonly IEditorialRepository _editorialRepository;
        public EditorialUpdateController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpPut("{id}")]
        [Route("api/editorials/{id}/update")]
        public IActionResult Update(int id, [FromBody] Editorial editorial)
        {
            if(editorial == null)
            {
                return BadRequest("El Objeto editorial es nullo");
            }
            _editorialRepository.Update(editorial);
            return Ok(new { message = "La Editorial Se Ha Actualizado Correctamente" });
        }
    }
}