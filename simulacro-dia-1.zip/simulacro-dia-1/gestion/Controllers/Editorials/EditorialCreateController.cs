using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Services;
using Microsoft.AspNetCore.Mvc;

namespace gestion.Controllers.Editorials
{
    public class EditorialCreateController : ControllerBase
    {
        private readonly IEditorialRepository _editorialRepository;
        public EditorialCreateController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpPost]
        [Route("api/editorials/create")]
        public IActionResult Create([FromBody] Editorial editorial)
        {
            if (editorial == null)
            {
                return BadRequest("El Objeto editorial es nullo");
            }
            _editorialRepository.Add(editorial);
            return Ok(new { message = "La Editorial Se Ha Creado Correctamente" });
        }
    }
}