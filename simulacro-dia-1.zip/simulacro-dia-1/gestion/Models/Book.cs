using System.ComponentModel.DataAnnotations;

namespace gestion.Models
{
    public class Book
    {
        public int Id { get; set; }
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? Pages { get; set; }
        [Required]
        public string? Language { get; set; }
        [Required]
        public DateOnly PublicationDate { get; set; }
        [Required]
        public string? Description { get; set; }
        [Required]
        public int AuthorId { get; set; }
        [Required]
        public Author? Author { get; set; }
        [Required]
        public int EditorialId { get; set; }
        [Required]
        public Editorial? Editorial { get; set; }
        [Required]
        public bool IsActive { get; set; } = true; // Campo para gestionar el estado

    }
}