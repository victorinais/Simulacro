using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Data;
using gestion.Models;

namespace gestion.Services
{
    public class EditorialRepository : IEditorialRepository
    {
        public readonly BaseContext _context;
        public EditorialRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Editorial editorial)
        {
            _context.Editorials.Add(editorial);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var editorial = _context.Editorials.Find(id);
            if(editorial != null)
            {
                editorial.IsActive = false;
                _context.Editorials.Update(editorial!);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Editorial> GetAll()
        {
            var editorials = _context.Editorials
                .Where(e => e.IsActive)
                .ToList();
            return editorials;
        }

        public Editorial GetById(int id)
        {
            var editorial =  _context.Editorials
                .FirstOrDefault(e => e.Id == id && e.IsActive);
            return editorial!;
        }

        public void Update(Editorial editorial)
        {
            _context.Editorials.Update(editorial);
            _context.SaveChanges();
        }
    }
    
}