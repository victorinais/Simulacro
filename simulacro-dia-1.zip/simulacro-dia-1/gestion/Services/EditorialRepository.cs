using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Data;
using gestion.Models;

namespace gestion.Services
{
    public class EditorialRepository : IEditorialRepository
    {
        public readonly BaseContext _context;
        public EditorialRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Editorial editorial)
        {
            _context.Editorials.Add(editorial);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var editorial = _context.Editorials.Find(id);
            _context.Editorials.Remove(editorial!);
            _context.SaveChanges();
        }

        public IEnumerable<Editorial> GetAll()
        {
            return _context.Editorials.ToList();
        }

        public Editorial GetById(int id)
        {
            return _context.Editorials.Find(id)!;
        }

        public void Update(Editorial editorial)
        {
            _context.Editorials.Update(editorial);
            _context.SaveChanges();
        }
    }
}