using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Data;
using gestion.Models;

namespace gestion.Services
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly BaseContext _context;
        public AuthorRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Author author)
        {
            _context.Authors.Add(author);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var author = _context.Authors.Find(id);
            if(author != null)
            {
                author.IsActive = false;
                _context.Authors.Update(author!);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Author> GetAll()
        {
            var authors = _context.Authors
                .Where(a => a.IsActive)
                .ToList();
            return authors;
        }

        public Author GetById(int id)
        {
            var author = _context.Authors
                .FirstOrDefault(a => a.Id == id && a.IsActive);
            return author!;
        }

        public void Update(Author author)
        {
            _context.Authors.Update(author);
            _context.SaveChanges();
        }
    }
}