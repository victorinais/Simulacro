using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;

namespace gestion.Services
{
    public interface IEditorialRepository
    {
        IEnumerable<Editorial> GetAll();
        Editorial GetById(int id);
        void Add(Editorial editorial);
        void Update(Editorial editorial);
        void Delete(int id);
    }
}