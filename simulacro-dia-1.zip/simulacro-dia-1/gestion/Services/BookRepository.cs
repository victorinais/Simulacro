using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gestion.Models;
using gestion.Data;
using gestion.Services;
using Microsoft.EntityFrameworkCore;

namespace gestion.Services
{
    public class BookRepository : IBookRepository
    {
        private readonly BaseContext _context;
        public BookRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Book book)
        {
            _context.Books.Add(book);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var book = _context.Books.Find(id);
            if(book != null)
            {
                book.IsActive = false;
                _context.Books.Update(book!);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Book> GetAll()
        {
            var books = _context.Books
                .Include(e => e.Author)
                .Include(e => e.Editorial)
                .Where(b => b.IsActive)
                .ToList();
            return books;
        }

        public Book GetById(int id)
        {
            var book = _context.Books
                .Include(b => b.Author)
                .Include(b => b.Editorial)
                .FirstOrDefault(b => b.Id == id && b.IsActive);
            return book!;
        }

        public void Update(Book book)
        {
            _context.Books.Update(book);
            _context.SaveChanges();
        }
    }

}