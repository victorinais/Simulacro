using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using Microsoft.EntityFrameworkCore;

namespace App.Services
{
    public class CitaRepository : ICitaRepository
    {
        private readonly BaseContext _context;
        public CitaRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Cita cita)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Cita> GetAll()
        {
            var citas = _context.Citas
                .Include(c => c.Medico)
                .Include(c => c.Paciente)
                .Where(c => c.Estado == EstadoCita.Activo)
                .ToList();
            return citas;
        }

        public Cita GetById(int id)
        {
            throw new NotImplementedException();
        }

        public void Update(Cita cita)
        {
            throw new NotImplementedException();
        }
    }
}