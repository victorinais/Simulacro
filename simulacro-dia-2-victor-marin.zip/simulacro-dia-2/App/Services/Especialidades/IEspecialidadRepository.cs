using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;

namespace App.Services
{
    public interface IEspecialidadRepository 
    {
        IEnumerable<Especialidad> GetAll();
        Especialidad GetById(int id);
        void Add(Especialidad especialidad);
        void Delete(int id);
        void Update(Especialidad especialidad);

    }
}