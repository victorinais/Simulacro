using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using Microsoft.EntityFrameworkCore;

namespace App.Services
{
    public class EspecialidadRepository : IEspecialidadRepository
    {
        private readonly BaseContext _context;
        public EspecialidadRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Especialidad especialidad)
        {
            _context.Especialidades.Add(especialidad);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var especialidad = _context.Especialidades.Find(id);
            if (especialidad != null)
            {
                especialidad.Estado = "inactivo";
                _context.Especialidades.Update(especialidad);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Especialidad> GetAll()
        {
            var especialidades = _context.Especialidades
                .Where(c => c.Estado == "activo")
                .ToList();
            return especialidades;
        }

        public Especialidad GetById(int id)
        {
            var especialidad = _context.Especialidades
                .Where(c => c.Estado == "activo")
                .FirstOrDefault(c => c.Id == id);
            return especialidad;
        }

        public void Update(Especialidad especialidad)
        {
            _context.Especialidades.Add(especialidad);
            _context.SaveChanges();
        }
    }
}