using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;

namespace App.Services
{
    public interface ICitaRepository
    {
        IEnumerable<Cita> GetAll();
        Cita GetById(int id);
        void Add(Cita cita);
        void Delete(int id);
        void Update(Cita cita);
        
    }
}