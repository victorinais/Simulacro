using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using Microsoft.EntityFrameworkCore;

namespace App.Services
{
    public class CitaRepository : ICitaRepository
    {
        private readonly BaseContext _context;
        public CitaRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Cita cita)
        {
            _context.Citas.Add(cita);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var cita = _context.Citas.Find(id);
            if (cita != null)
            {
                cita.Estado = "inactivo";
                _context.Citas.Update(cita);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Cita> GetAll()
        {
            var citas = _context.Citas
                .Include(c => c.Medico)
                .Include(c => c.Paciente)
                .Where(c => c.Estado == "activo")
                .ToList();
            return citas;
        }

        public Cita GetById(int id)
        {
            var cita = _context.Citas
                .Include(c => c.Medico)
                .Include(c => c.Paciente)
                .Where(c => c.Estado == "activo")
                .FirstOrDefault(c => c.Id == id);
            return cita;
        }

        public void Update(Cita cita)
        {
            _context.Citas.Add(cita);
            _context.SaveChanges();
        }
    }
}