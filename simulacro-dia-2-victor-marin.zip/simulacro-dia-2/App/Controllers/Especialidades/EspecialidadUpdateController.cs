using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Especialidades
{
    public class EspecialidadUpdateController : ControllerBase
    {
        private readonly IEspecialidadRepository _especialidadRepository;
        public EspecialidadUpdateController(IEspecialidadRepository especialidadRepository)
        {
            _especialidadRepository = especialidadRepository;
        }

        [HttpPut("{id}")]
        [Route("api/especialidad/update/{id}")]
        public IActionResult Update(int id, [FromBody] Especialidad especialidad)
        {
            if(especialidad == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _especialidadRepository.Update(especialidad);
            return Ok(new { message = "La Especialidad Se Ha Actualizado Correctamente" });
        }
    }
}