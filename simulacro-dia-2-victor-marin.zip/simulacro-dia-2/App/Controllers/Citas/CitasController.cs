using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Citas
{
    public class CitasController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitasController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }

        [HttpGet]
        [Route("api/citas")]
        public IEnumerable<Cita> GetCitas(){
            return _citaRepository.GetAll();
        }
        [HttpGet]
        [Route("api/citas/{id}")]
        public Cita Details(int id){
            return _citaRepository.GetById(id);
        }
    }
}