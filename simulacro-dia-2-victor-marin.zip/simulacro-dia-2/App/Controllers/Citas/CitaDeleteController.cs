using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Citas
{
    public class CitaDeleteController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitaDeleteController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/citas/delete/{id}")]
        public IActionResult Delete(int id)
        {
            _citaRepository.Delete(id);
            return Ok(new { message = "La cita Ha Cambiado de Estdo Correctamente" });
        
        }
    }
}