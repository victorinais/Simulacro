using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Citas
{
    public class CitaUpdateController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitaUpdateController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }
        [HttpPut("{id}")]
        [Route("api/citas/update/{id}")]
        public IActionResult Update(int id, [FromBody] Cita cita)
        {
            if(cita == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _citaRepository.Update(cita);
            return Ok(new { message = "La cita Se Ha Actualizado Correctamente" });
        }
        
    }
}