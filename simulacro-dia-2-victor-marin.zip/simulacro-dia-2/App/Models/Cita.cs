using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace App.Models
{
    public class Cita
    {
        public int Id { get; set; }
        public int MedicoId  { get; set; }
        public Medico? Medico { get; set; }
        public int PacienteId { get; set; }
        public Paciente? Paciente { get; set; }
        public DateOnly Fecha { get; set; }
        public string? Estado { get; set; }

        [JsonIgnore]
        public List<Tratamiento>? Tratamientos { get; set; }
    }
}